# Build Fairlys-Adventure V1.0

The source matches the V.39 game code, renamed for the V1.0 release.
The ROM uses NTSC, 32 KB F4 banking and the original 128-byte RAM.
Testing shortcuts are removed.

## Windows build

1. Extract the ZIP into a writable folder.
2. Open PowerShell in the Source folder.
3. Install the portable build dependencies by running:
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\setup-tools.ps1`
   This downloads the tools into Source/tools and requires internet access.
   For manual installation, see TOOLS-REFERENCE.md and setup-tools.ps1.
4. Build with:
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -NoPublish`
5. The result is Source/dungeon.bin. It should match the supplied
   Fairlys-Adventure-V1.0.bin byte for byte.

Compiler binaries are not included in this release. The setup script records
exact package versions and URLs. The build scripts compile batari Basic and
custom assembly, then combine the banks into the final ROM. Use -NoPublish
to avoid creating a new development version number.

These scripts target Windows. macOS/Linux builds are not configured here.
