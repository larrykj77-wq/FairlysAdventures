Fairly's Adventure - V1.0

PLAY: Open Fairlys-Adventure-V1.0.bin in standalone Stella.
Format: Atari 2600 NTSC, 32 KB F4 cartridge.
Joystick port 1. Arrow keys move; Space is Fire in the project's keyboard
setup. Emulator mappings may be changed. F2 is Reset.

Manuals/ contains the Quick Start and Complete Game Play - Spoilers guides.
Artwork/ contains the approved renamed cover.
Source/ contains game source and build scripts; compiler tools are not bundled.
TOOLS-REFERENCE.md lists the external tools and versions used.
See BUILD-INSTRUCTIONS.md to rebuild.

Release identity: V1.0 is the approved dungeonV.39.bin code under the final
release filename. It adds no gameplay changes beyond V.39. Testing shortcuts
are removed. Enemy kills give no gold; dragon defeat gives no automatic lives.
The dragon reward chest still grants one life, subject to the ten-life cap.

Game-Tables.xlsx contains damage by armor tier, final wand
tables, calculated dragon hits to kill, and loot tables.

License: covered game code and derived ROMs may be played, modified and
shared free of charge. Sales are prohibited. Retain Larry Johnson credit
and license notices. See LICENSE and THIRD-PARTY-NOTICES.md for full terms
and the separate CC0 rights of third-party support code.
