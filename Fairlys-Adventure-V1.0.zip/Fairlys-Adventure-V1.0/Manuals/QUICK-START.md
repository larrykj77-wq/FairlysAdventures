# Fairly's Adventure - Quick Start

One player - Atari 2600 NTSC. Controller port 1.

## Controls

| Action | Joystick / console | Stella keyboard |
| --- | --- | --- |
| Move and face | Up, down, left or right | Arrow keys |
| Cast, open or buy | Fire | Space |
| Restart | Reset | F2 |

Keyboard mappings can be changed. Press Fire on the title screen to start.
Tap Fire to cast in the direction Fairly faces; release between shots.
Approach chests or shop items and press Fire to interact.

## Your adventure

Explore five dungeon levels. Clear combat rooms to open their exits, collect
chest rewards and improve your equipment. You start with 5 health and 3 lives.

| HUD | Meaning |
| --- | --- |
| HP | Health |
| GP | Gold |
| LV | Lives remaining |
| WP | Wand tier |
| AR | Armor tier |
| GL | Game level |

In shops, the left WP chest sells wand upgrades for 15 gold, the right AR
chest sells armor upgrades for 15 gold, and the center merchant restores
health for 5 gold. Health reaches 5; gold is capped at 25.

Losing a life restores health while keeping gear, gold and game level.
After GAME OVER, release Fire and press again to start a new adventure.
Defeat each level's dragon and discover the way onward.

Read the companion **Complete Game Play** manual when you want the full
explanation of enemies, rewards, armor, dragon warnings and progression.
