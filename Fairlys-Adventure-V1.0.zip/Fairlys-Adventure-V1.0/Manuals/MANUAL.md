# Fairly's Adventure

## Complete Game Play

One player - Atari 2600 NTSC.

![Title screen](manual-assets/title.png)

Guide Fairly through five dungeon levels. Defeat monsters, gather gold, improve
your wand and armor, and face each level's dragon. Beyond the fifth dragon's
locked rear door, a treasure vault awaits.

## 1. Start your adventure

Connect a joystick to the first controller port. Press Fire on the title screen
to start. If Fire was already held, release it and press again.

| Action | Atari joystick / console | Project's Stella keyboard setup |
| --- | --- | --- |
| Move and face a direction | Joystick up, down, left or right | Arrow keys |
| Cast, open a chest or buy | Fire button | Space |
| Restart the adventure | Reset switch | F2 |

In the treasure ending, Reset/F2 returns to the title instead. Emulator mappings
can be changed in its settings.

Each Fire press casts one wand shot in the direction Fairly faces. Release Fire
between shots; holding it does not auto-fire. There is a short cooldown and only
one active shot at a time. A dull tick means a shot was blocked or ineffective;
a bright hit sound and enemy flash confirm a successful hit.

You start at game level 1 with **5 HP, 3 lives, wand tier 1, armor tier 0 and
0 gold**.

## 2. Read the HUD

![Dungeon and HUD](manual-assets/gameplay.png)

The six fields stay visible below the room:

| Field | Meaning | What to remember |
| --- | --- | --- |
| HP | Current health | Maximum 5 at every game level. |
| GP | Gold | Carry at most 25. |
| LV | Lives remaining | Total lives, not just spare lives. Maximum 10. |
| WP | Wand tier |  |
| AR | Armor tier |  |
| GL | Game level | Progress from 1 through 5. Its text color changes by level. |

## 3. Explore rooms and collect treasure

Defeat all enemies in an ordinary combat room to unlock its exits. Approach the
treasure chest and press Fire to open it.

Chest contents vary: **0-2 gold**, healing, a wand upgrade or an armor upgrade.
A healing chest restores 2 HP, up to 5. Equipment upgrades add one tier and
respect the current level's cap. If healing or an upgrade cannot be used, the
reward can become a gold roll. Some gold chests are empty.

Leave through an open doorway to encounter another room. Shops, firewalls and
dragons interrupt the normal monster encounters. Do not rely on a saved map of
cleared rooms; fresh encounters are part of exploring the dungeon.

### Know your enemies

- **Skeletons:** alternate between wandering and following Fairly.
- **Bats:** move unpredictably in random directions, including diagonals.
- **Slimes:** wander, pursue and lunge. Give them space when they surge forward.

Level 1 has one ordinary enemy per combat room. Later skeleton and slime rooms
can contain two independent enemies. Enemy movement becomes faster at higher
game levels. Quiet rattles, squeaks and bubbling sounds help identify the type;
important combat sounds take priority over these background calls.

### Moving firewall rooms

![Moving firewall](manual-assets/firewall.png)

A moving wall of fire leaves an opening to pass through. Line up with the gap
and move through it as the wall sweeps across the room. Contact costs health;
firewall rooms do not provide the initial safety period of ordinary combat
rooms. The firewall is different from the instantly lethal lava in dragon rooms.

## 4. Shop for equipment and healing

![Shop: WP chest on the left, merchant in the center, AR chest on the right](manual-assets/shop.png)

Approach the item you want and press Fire. Release Fire between purchases.

| Position | Purchase | Cost |
| --- | --- | --- |
| Left chest, WP | Wand +1 tier | 15 gold |
| Merchant in the center | Restore health to 5 | 5 gold |
| Right chest, AR | Armor +1 tier | 15 gold |

A rising chime and green merchant flash confirm a purchase. A low buzz and
failure flash mean nothing was bought. You are not charged when an item is
capped, health is already full, or you cannot afford the purchase.

Wand upgrades increase damage. Armor 0 and 1 block no damage; every tier above
1 blocks one point of ordinary-enemy and dragon damage, with a minimum of
1 damage per hit. Armor never protects against lava.

Because you can carry only 25 gold, spend it deliberately. Upgrade equipment
for the current game level before taking on its dragon.

## 5. The Dragon

![Fire breath](manual-assets/dragon-fire.png)
![Gold recovery](manual-assets/dragon-gold.png)

The dragon faces left and warns you before each fire cone:

| Foot movement | Incoming cone |
| --- | --- |
| Upper foot draws back | Upper part of the arena |
| Both feet move | Middle of the arena |
| Lower foot draws back | Lower part of the arena |

Read the warning each time: directions are random and may repeat. A pulsing
rumble supports the foot cue. Move out of the warned path before the breath.

**Attack only when the dragon turns gold.** During this recovery period, aim
wand shots at its head. The chime announces the opportunity; a bright hit sound
and white flash confirm damage. Other head shots are blocked.

**Permanent orange pools are lava.** Touching lava instantly costs one life,
even with armor or invulnerability flashing. It remains dangerous after the
dragon is defeated. Stay on clear floor when collecting rewards and crossing
to the rear door.

If you are not ready, retreat through the opening on the left wall, above the
arena's center. You keep your current level, gear, gold and lives. A later
dragon encounter starts with full dragon health.

### Dragon rewards and the rear door

After defeating the Dragon, two chests appear:

- **Upper chest:** the key to the door behind the dragon.
- **Lower chest:** one guaranteed extra life, plus wand +1 if below the level
  cap. The extra life is awarded whether or not the wand upgrades, up to 10
  total lives. Each chest can be collected once.

Collect the key, then cross the rear door on the right to enter the next game
level. Current health, lives, gold and equipment carry forward. The level 5
door leads to the ending rather than a sixth level.

## 6. The ice dragon and five game levels

![Level-five ice wall](manual-assets/ice-dragon.png)

The level 5 blue dragon alternates a slow-moving ice wall with one random fire
cone. The wall has **one small opening**, chosen high, middle or low for each
sweep. It stays at that height until the wall passes.

An ice hit deals the same armor-scaled damage as the fire breath and freezes
Fairly. **Both movement and shooting stop until the following fire
cone ends.** That cone may miss a frozen Fairly, but survival is not guaranteed.
Use the clear floor to align with the gap; do not step into lava to reach it.

| Game level | Wand / armor cap | Ordinary enemy HP | Dragon HP | Base hit damage |
| --- | --- | --- | --- | --- |
| 1 | 5 | 5 | 40 | 5 |
| 2 | 10 | 19 | 80 | 10 |
| 3 | 15 | 30 | 150 | 15 |
| 4 | 20 | 37 | 260 | 20 |
| 5 | 25 | 71 | 375 | 25 |

Base hit damage applies to ordinary enemies and dragons before armor.
Subtract one damage for each armor tier above 1, but never below 1 damage.
For example, at game level 2, armor 9 reduces a 10-point hit to **2 HP**.
Your wand damage always equals WP. High-level hits can cost a life immediately
if your armor is too low.

At armor 25, the level 5 dragon's ice and fire each deal 1 damage. Lava still
instantly costs a life.

## 7. Lives, defeat and victory

### Losing a life

You return with 5 HP and keep the current game level, gold, wand and armor.
The room resets; if you were fighting a dragon, its full health is restored.
Use the remaining lives wisely rather than depending on damage carrying over
between attempts.

![Game over](manual-assets/game-over.png)

Losing the final life shows **GAME OVER** and the game level reached. A short
descending tune plays, then stops. Release Fire and press again to begin a
fresh level 1 adventure with the original starting stats. Reset/F2 also restarts.

### The treasure vault

![Treasure ending](manual-assets/ending.png)

Defeat the fifth dragon, collect its key and pass through the rear door to win.
Fairly walks to the center of the treasure vault automatically while victory
music plays. Movement and shooting are disabled during this celebration.
The gold, rubies and sapphires are the victory scene, not extra spendable gold.
Reset/F2 returns to the title.
